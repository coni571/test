#!/data/data/com.termux/files/usr/bin/bash
# Mein Script fuer DE-Gruppen
message1="ENDE/Koniec  LiveTV DE-Listen sind nun erstellt"
message2="Schliesse jetzt TERMUX und starte TELEVIZIO"
message3="         Bitte warten....."
cp -r lighttpd/www/Poland.m3u8 sdcard/Poland.m3u;
cp -r lighttpd/www/Poland.m3u8 lighttpd/www/Poland.m3u
cp -r lighttpd/www/playlist_de.py lighttpd/www/playlist.py;
clear
pkill lighttp
/data/data/com.termux/files/usr/bin/lighttpd -f /data/data/com.termux/files/home/lighttpd.conf;
echo -e "\033[31m$message3"
echo -e "\033[37m "
# curl -v http://0.0.0.0:8080/sig.php
curl -v http://0.0.0.0:8080/m3u8.php
cp -r lighttpd/www/Germany.m3u8  lighttpd/www/Germany.m3u;
cp -r lighttpd/www/Germany.m3u8  sdcard/Germany.m3u;
echo -e "\033[35m$message1"
echo -e "\033[32m$message2"
exit

