#!/data/data/com.termux/files/usr/bin/bash

/data/data/com.termux/files/usr/bin/lighttpd -f /data/data/com.termux/files/home/lighttpd.conf;
