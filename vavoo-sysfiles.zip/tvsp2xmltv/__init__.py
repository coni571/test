#!/data/data/com.termux/files/usr/bin/python2
# -*- coding: utf-8 -*-
