#!/data/data/com.termux/files/usr/bin/bash
# Mein Script fuer KEY-Schlüssel <sig.php>
message1="ENDE/Koniec  TV-Schlüssel ist nun erstellt"
message2="Schliesse jetzt TERMUX und starte start_de.sh oder start_pl.sh"

message3="          Bitte warten ...."
pkill lighttpd
echo -e "\033[31m$message3"
echo -e "\033[37m "
/data/data/com.termux/files/usr/bin/lighttpd -f /data/data/com.termux/files/home/lighttpd.conf;
curl -v http://0.0.0.0:8080/sig.php
echo -e "\033[35m$message1"
echo -e "\033[32m$message2"
exit

